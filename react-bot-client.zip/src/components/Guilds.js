import React from 'react';

class Guilds extends React.Component {

  render() {
    return (
      <div className="Guilds">
      </div>
    );
  }
}

export default Guilds;
